from pymongo import ASCENDING, DESCENDING, MongoClient

from ..core.config import DATABASE_NAME, MONGO_URI

client = None
db = None


def init_database():
    global client, db
    if not MONGO_URI:
        return None
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
    client.admin.command("ping")
    db = client[DATABASE_NAME]
    db.users.create_index([("email", ASCENDING)], unique=True)
    db.predictions.create_index([("user_id", ASCENDING), ("created_at", DESCENDING)])
    return db


def get_database():
    return db